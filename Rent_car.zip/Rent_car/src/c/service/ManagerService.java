package c.service;

import c.common.ConnectionFactory;
import c.model.dao.MemberDao;
import c.model.vo.Member;

import java.sql.Connection;
import java.sql.SQLException;

public class ManagerService {
    private ConnectionFactory factory;

    public ManagerService() {
        factory = ConnectionFactory.getConnection();
    }


}
