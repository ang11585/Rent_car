package c.model.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import c.common.ConnectionFactory;
import c.model.vo.Rent;

public class RentDao {
    public ArrayList<Rent> selectRent(Connection conn) {
        ArrayList<Rent> list = null;
        Statement stmt = null;
        ResultSet rset = null;
        String query = "SELECT * FROM RENT";

        try {
            stmt = conn.createStatement();
            rset = stmt.executeQuery(query);
            list = new  ArrayList<Rent>();
            while(rset.next()) {
                Rent rent = new Rent();
                rent.setRentNo(rset.getInt("RENT_NO"));
                rent.setCarNo(rset.getInt("CAR_NO"));
                rent.setMemberNo(rset.getInt("MEMBER_NO"));
                rent.setRentStart(rset.getDate("RENT_START"));
                rent.setRentEnd(rset.getDate("RENT_END"));
                rent.setRentCost(rset.getInt("RENT_COST"));
                rent.setInsuranceVariety(rset.getString("INSURANCE_VARIETY"));
                rent.setInsuranceCost(rset.getInt("INSURANCE_COST"));
                list.add(rent);
            }
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } finally {
            ConnectionFactory.close(stmt);
            ConnectionFactory.close(rset);
        }
        return list;
    }
}
