package c.model.dao;

import c.common.ConnectionFactory;
import c.model.vo.Member;
import myException.CarException;

import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

public class MemberDao {
    private Properties prop;

    public MemberDao() {
        prop = new Properties();
        try {
            prop.load(new FileReader("resources/query.properties"));
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    public int insertMember(Member member, Connection conn) throws CarException {
        int result = 0;
        Statement stmt = null;

        String query = prop.getProperty("insertMember");


        try {
            PreparedStatement pstmt = null;
            pstmt = conn.prepareStatement(query);
            pstmt.setString(1, member.getMemberId());
            pstmt.setString(2,member.getMemberPwd());
            pstmt.setString(3, member.getMemberName());
            pstmt.setDate(4,member.getMemberBirth());
            pstmt.setString(5,member.getMemberPhone());
            pstmt.setString(6,member.getMemberEmail());
            pstmt.setString(7,member.getMemberLicenseType());
            pstmt.setString(8,member.getMemberLicenseNo());
            pstmt.setDate(9,member.getMemberTestExp());
            pstmt.setString(10,member.getMemberAddress());
            result = pstmt.executeUpdate();



        } catch (SQLException e) {
            throw new CarException(
                    "insertMember() 메소드 처리 불가" + e.getMessage());
        }finally {
            ConnectionFactory.close(stmt);
        }
        return result;

    }
    public int secession(String userId,Connection conn) {
        int result = 0;
        PreparedStatement pstmt = null;
        String query = "DELETE FROM MEMBER WHERE MEMBER_ID = ?";
        try {
            pstmt = conn.prepareStatement(query);
            pstmt.setString(1, userId);
            result = pstmt.executeUpdate();
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } finally {
            ConnectionFactory.close(pstmt);
        }

        return result;
    }

}
