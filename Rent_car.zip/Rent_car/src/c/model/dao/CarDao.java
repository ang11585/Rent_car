package c.model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import c.common.ConnectionFactory;
import c.model.vo.Car;

public class CarDao {
    public ArrayList<Car> selectAllCar(Connection conn) {
        ArrayList<Car> list = null;
        Statement stmt = null;
        ResultSet rset = null;
        String query = "SELECT * FROM CAR";
        try {
            stmt = conn.createStatement();
            rset = stmt.executeQuery(query);
            list = new ArrayList<Car>();
            while(rset.next()) {
                Car car = new Car();
                car.setCarNo(rset.getInt("CAR_NO"));
                car.setCarId(rset.getString("CAR_ID"));
                car.setCarSize(rset.getString("CAR_SIZE"));
                car.setCarName(rset.getString("CAR_NAME"));
                car.setCarFuel(rset.getString("CAR_FUEL"));
                car.setCarCost(rset.getInt("CAR_COST"));
                list.add(car);
            }
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }finally {
            ConnectionFactory.close(stmt);
            ConnectionFactory.close(rset);
        }
        return list;
    }
    public int insertCar(Car car, Connection conn) {
        int result = 0;
        PreparedStatement pstmt = null;
        String query = "INSERT INTO CAR VALUES(CAR_NO_SEQ.NEXTVAL, ?, ?, ?, ?, ?)";
        try {
            pstmt = conn.prepareStatement(query);
            pstmt.setString(1, car.getCarId());
            pstmt.setString(2, car.getCarSize());
            pstmt.setString(3, car.getCarName());
            pstmt.setString(4, car.getCarFuel());
            pstmt.setInt(5, car.getCarCost());
            result = pstmt.executeUpdate();
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } finally {
            ConnectionFactory.close(pstmt);
        }
        return result;
    }
}
