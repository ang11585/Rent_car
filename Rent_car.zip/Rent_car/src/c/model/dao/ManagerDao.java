package c.model.dao;

public class ManagerDao {
}
