package c.run;

import c.view.CarMenu;

public class Run {
    public static void main(String [] args) {
        CarMenu carMenu = new CarMenu();
        carMenu.MainMenu();

    }
}
