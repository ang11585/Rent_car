package myException;

public class CarException extends Exception {
    public CarException() {
        super();
    }
    public CarException(String message) {
        super(message);
    }
}
